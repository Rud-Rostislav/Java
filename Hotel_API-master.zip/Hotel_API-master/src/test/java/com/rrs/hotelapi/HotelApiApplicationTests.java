package com.rrs.hotelapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
